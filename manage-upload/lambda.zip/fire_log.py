import sys
import os
import datetime
import time
import fire_basic as fb
import alert

def status_log(code, sqs_name, group, key, dir, name, text):

    bucket    = "firestorage-data"
    unix_time = int(time.time())

	# "$dir/$sqs_name/$host_name/$datem/$dateh/${fgrp}/${fkey}/${fdir}/${name}/${code}";
    # unixtimeを読める形に
    dt = datetime.datetime.fromtimestamp(unix_time)
    # JSTとUTCの差分日本時間にセット
    DIFF_JST_FROM_UTC = 9
    dt = dt + datetime.timedelta(hours=9)

    hostname = os.uname()[1]
    yyyymmdd = dt.strftime('%Y%m%d')
    hhmmss   = dt.strftime('%H%M%S')

    print("group:" + group, file=sys.stderr)
    print("key:"   + key,   file=sys.stderr)
    print("name:"  + name,  file=sys.stderr)

    dir2 ='info.log'
    if code != 200:
        dir2 = 'alert.log'
    else:
        text = '{}'

    file = dir2 + '/' + sqs_name + '/' + hostname + '/' + yyyymmdd + '/' + hhmmss + '/' + group + '/' +  key + '/' +  dir + '/' + name + '/' + str(code)

    code = fb.s3_simple_put(bucket, file, text)

    if "alert" in sys.modules:
        code = alert.send("info", "check console logs : " + file)

    return code

