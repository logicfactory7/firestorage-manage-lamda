﻿import json
import urllib.parse
import math
import boto3
import os
import redis
import random
import mimetypes
import time
import datetime
import fire_basic

from botocore.client import Config
from redis.cluster import RedisCluster, ClusterNode

_upload_cache_data = {}

def access_count_check(rc, env):

    ip = str(env['identity']['sourceIp'])

    # アクセス回数 超えたら 400
    mem_key = "download_count:" + ip

    rep = rc.get(mem_key)

    if rep is None:
        rc.set(mem_key, 1, ex=120, nx=True)
        rep = 1
    else:
        if int(rep) > 30:
            return 400, 0
        rep = rc.incr(mem_key)

    return 200, rep

def create_top_comments(rc, key, upload_tbl, asp, payed, s3_message):

    code, text = get_setting_data(rc, 'download', 'top_comments.html')
    if code != 200:
        return 500, 'top_comments.html get error', ''

    comment = upload_tbl['comment']
    comment = fire_basic.html_escape(comment)
    comment = comment.replace('\n', '<br />')

    #comments_title
    text = text.replace("<comments_title>",s3_message['9'])
    text = text.replace("<next>",s3_message['27'])
    text = text.replace("<messages>", comment)
    text = text.replace("<wait>", s3_message['wait'])

    return code, text

def download_form(rc, json_data, download_limit_time, s3_message):

    action = json_data['action']

    payed = get_payed(json_data)
    asp   = get_asp(json_data)

    if 'foce_onetime' in os.environ:
        if os.environ['foce_onetime'] == '1':
            payed = 0
            asp = ""

    # メッセージ
    download_message = s3_message['0']

    if action == "download":
        #旧ダウンロード

        # htmlを作成
        code, item, download_service = create_download_item(json_data, s3_message, download_limit_time)

        # ユーザー削除
        item, add_box = create_user_delete(rc, json_data, s3_message, item)

        # メッセージ
        item = create_user_message_item(json_data, item)

        if int(payed) > 0 or len(asp) > 1:
            # 法人と有料
            code, text = get_setting_data(rc, 'download', 'download_box_simple.html')
            if code != 200:
                return 500, 'download_box_simple.html get error', ''

        else:

            # 無料・未登録
            code, text = get_setting_data(rc, 'download', 'download_box_main.html')
            if code != 200:
                return 500, 'download_box_main.html get error', ''

            text = set_ad_news(rc, text)

        text = text.replace("<download_message>", download_message)
        text = text.replace("<item>", item)

        # ダウンロード有効
        text = download_exp(text, download_limit_time)

        # ダウンロード有効
        text = download_del_time(text, json_data['data']['del_time'])

        text += add_box

        # URLエンコードして送る
        text = urllib.parse.quote(text)

        return 200, text, download_service

    else:
        return 500, '', ''


def create_user_delete(rc, json_data, lang_data, item):

    user_delete       = json_data['data']['del']
    cr = "\n"
    add_box = ""

    if user_delete == '2':

        code, add_box = get_setting_data(rc, 'download', 'download_delete_alert.html')

        msg1 = lang_data['62']
        msg2 = lang_data['59']

        onclick = "download_user_delete_file('new_key', 'remove_id,file_delete_box', 'html_id,file_list1,lang_71')"

        lang_text  = '<input type="hidden" id="lang_71" value="' + lang_data['71'] + '">' + cr
        lang_text += '<input type="hidden" id="lang_62" value="' + lang_data['62'] + '">' + cr
        lang_text += '<input type="hidden" id="lang_63" value="' + lang_data['63'] + '">' + cr
        lang_text += '<input type="hidden" id="lang_70" value="' + lang_data['70'] + '">' + cr
        lang_text += '<input type="hidden" id="lang_71" value="' + lang_data['71'] + '">' + cr
        lang_text += '<input type="hidden" id="lang_cancel" value="' + lang_data['cancel'] + '">' + cr
        lang_text += '<input type="hidden" id="lang_close" value="' + lang_data['close'] + '">' + cr
        lang_text += '<input type="hidden" id="lang_wait" value="' + lang_data['wait'] + '">' + cr
        lang_text += '<input type="hidden" id="lang_error_message" value="' + lang_data['error_message'] + '">' + cr

        text = '<tr class="bg-white" >' + cr
        text += '  <td class="align-middle text-end" colspan="3">' + cr
        text += '     <span class="pe-2">' + msg1 + '</span> <button type="button" class="btn btn-warning btn-sm float-end pt-0 pb-0 text-white" onclick="' + onclick + '">' + msg2 + '</button>' + cr
        text += lang_text
        text += '  </td>' + cr
        text += '</tr>' + cr
        item += text

    return item, add_box

def create_user_message_item(json_data, item):

    comment = json_data['data']['comment']
    comment = fire_basic.html_escape(comment)
    comment = comment.replace('\n', '<br />')

    if comment:
        text = '<tr class="bg-white">'
        text += '  <td class="align-middle" colspan="3">' + comment + ' </td>'
        text += '</tr>'
        item = text + item

    return item

def create_download_item(json_data, s3_message, download_limit_time):

    title       = json_data['data']['title']
    copy_size   = json_data['data']['copy_size']
    add_time    = json_data['data']['add_time']
    upload_file = json_data['upload']['upload_file']

    title = urllib.parse.unquote(title)

    # ダウンロードファイル名 ファイル名禁止文字を変換
    download_name_val = donwload_file_validation(title)

    #エンコード
    download_name_val = urllib.parse.quote(download_name_val)

    # download service候補リストを出す
    download_service = get_download_server(json_data)

    if download_service is None:
        return 500, 'download_service not found', ""

    # s3設定データを取得
    code, endpoint_url, region, bucket, access_key, secret_key = get_s3_config(download_service)

    print("download_service:" + str(code))
    print("download_service:" + download_service)
    print("download_bucket:" + bucket)
    print("download_access_key:" + access_key)
    print("download_download_name_val:" + download_name_val)


    if code > 201:
        return 500, 'download_service config not found', download_service

    # debug
    mime = mimetypes.guess_type(title)[0]

    # 署名付きURLの生成
    url = s3_generate_presigned_url(endpoint_url, bucket, upload_file, region, access_key, secret_key, download_limit_time, download_name_val, mime)

    # 表示名を作成 htmlエスケープ
    title = html_escape(title)

    onclick = "onclick=\"download_file('" + url + "', '" + download_name_val + "', '" + str(copy_size) + "', '" + download_service + "')\""

    link = "<a href=\"javascript:void(0);\" " + onclick + " class=\"ps-2\">" + title + "</a>\n"

    dt = datetime.datetime.fromtimestamp(add_time)

    # <button type="button" class="btn btn-warning btn-sm d-none d-lg-block" ' + onclick + '><small class="text-white">ダウンロード</small></button>

    item = '<tr class="bg-white" title="' + str(code) + download_service + '">'
    item += '  <td class="align-middle text-wrap"> <img ' + onclick + ' width="16" height="16" align="absmiddle" src="https://posh.firestorage.jp/images/silk/cloud_download.png" style="cursor: pointer;">' + link + '</td>'
    item += '  <td class="align-middle">' + convert_size(int(copy_size)) + '</td>'
    item += '  <td class="align-middle text-end pe-2">' + str(dt) + '</td>'
    item += '</tr>'

    return 200, item, download_service


def download_del_time(text, del_time):

    dt = ""

    if del_time == '0':
        dt = "特になし"
    else:
        t2 = int(time.time() + ( 9 * 3600) )
        dt = datetime.datetime.fromtimestamp(t2 + int(del_time))

    text = text.replace("<htime>", str(dt))

    return text

def download_exp(text, download_limit_time):

    # ダウンロード有効
    t2 = int(time.time() + ( 9 * 3600) )
    dt = datetime.datetime.fromtimestamp(t2 + download_limit_time)
    text = text.replace("<dtime>", str(dt))

    return text

def set_ad_news(rc, text):

    # 広告の置換
    stage = os.environ['stage']

    data = rc.hgetall('setting/' + stage + ":ad")

    news = '<li class="list-group-item text-center ps-1 pe-1">ニュースはありません</li>'

    if data is None:
        text = text.replace("<ad_top>","")
        text = text.replace("<ad_full>","")
        text = text.replace("<ad1>" , "")
        text = text.replace("<ad2>" , "")
        text = text.replace("<ad3>" , "")
        text = text.replace("<ads1>", "")
        text = text.replace("<ads2>", "")
        text = text.replace("<ads3>", "")
    else:
        ad1 = json.loads(data['ad1'.encode()].decode())
        ad2 = json.loads(data['ad2'.encode()].decode())
        ad3 = json.loads(data['ad3'.encode()].decode())
        adf = json.loads(data['ad_full'.encode()].decode())
        ads1 = json.loads(data['ads1'.encode()].decode())
        ads2 = json.loads(data['ads2'.encode()].decode())
        ads3 = json.loads(data['ads3'.encode()].decode())
        news = json.loads(data['news_json'.encode()].decode())

        text = text.replace("<ad_full>", adf['body'])
        text = text.replace("<ad1>" , ad1['body'])
        text = text.replace("<ad2>" , ad2['body'])
        text = text.replace("<ad3>" , ad3['body'])
        text = text.replace("<ads1>", ads1['body'])
        text = text.replace("<ads2>", ads2['body'])
        text = text.replace("<ads3>", ads3['body'])

        news_text = news['body']
        json_data = json.loads(news_text)
        length = json_data['length']
        news = ""

        for num in range(7):
            i = random.randint(0, length - 1)
            title  = json_data['list'][i]['title']
            href   = json_data['list'][i]['href']
            news   += '<li class="list-group-item text-start ps-1 pe-1"><a href="' + href + '" target="_blank"><small>' + title + '</small></a></li>'

    text = text.replace("<news>", news)

    return text

def set_news(rc, text):

    stage = os.environ['stage']

    data = rc.hget("setting/" + stage + ":ad", "ad_news_js")

    if data is None:
        return ""

    json_data = json.loads(data)
    body = json_data['body']

    # news
    data = rc.hget("setting/" + stage + ":json", "news")


    return text


def get_setting_data(rc, type, key):

    stage = os.environ['stage']

    rep = rc.hget('setting/' + stage + ':' + type, key)
    if rep is None:
        return 404, key

    text = rep.decode('utf8')
    json_data = json.loads(text)
    text = json_data['body']

    return 200, text

def get_download_server(json_data):

    # 候補リストを出す
    download_server_list  = json_data['download']['list']

    download_service = random.choice(download_server_list)

    target = download_service['service']

    return target

def monitor_sqs(event, action, key):

    env = event.get('requestContext')

    t2 = int(time.time())

    data = {
         'action': "cushion" ,
         'time': t2 ,
         'key': key ,
         'env': env
    }

    sqs_client = boto3.client("sqs")
    queue_url = "https://sqs.ap-northeast-1.amazonaws.com/firestorage-monitor-sqs"
    response = sqs_client.send_message(QueueUrl=queue_url, MessageBody=json.dumps(data))

def donwload_file_validation(s):
    s = s.replace("\\", "￥")
    s = s.replace("/", "／")
    s = s.replace(":", "：")
    s = s.replace("*", "＊")
    s = s.replace("?", "？")
    s = s.replace("\"", "”")
    s = s.replace("<", "＜")
    s = s.replace(">", "＞")
    s = s.replace("|", "｜")
    s = s.replace("`", "｀")
    s = s.replace(",", "，")
    return s

def s3_generate_presigned_url(endpoint_url, bucket_name, object_key, region, access_key, secret_key, expiration, download_name, mime):

    ResponseContentDisposition = "attachment; filename*=UTF-8''" + download_name
#   filename*=UTF-8''[UTF-8のファイル名をURLエンコードしたもの]

    s3_client = boto3.client('s3', config=Config(signature_version='s3v4'), endpoint_url=endpoint_url, region_name=region, aws_access_key_id=access_key, aws_secret_access_key=secret_key)

    if mime is None:
        return s3_client.generate_presigned_url('get_object', Params={'Bucket': bucket_name, 'Key': object_key, 'ResponseContentDisposition' : ResponseContentDisposition }, ExpiresIn=expiration)
    else:
        return s3_client.generate_presigned_url('get_object', Params={'Bucket': bucket_name, 'Key': object_key, 'ResponseContentDisposition' : ResponseContentDisposition, 'ResponseContentType' : mime }, ExpiresIn=expiration)


def get_s3_config(s):

    global _upload_cache_data

    # 署名URLを作成
    bucket = ''
    endpoint_url = ''
    access_key = ''
    secret_key = ''
    region = ''
    code = 200

#   print("get_s3_config:" + s)

    if s == 'wasabi-firestorage-data':
        bucket = 'firestorage-data'
        endpoint_url = "https://s3.ap-northeast-1.wasabisys.com"
        region = 'ap-northeast-1'
        access_key = '9FMFZDLIR2TGLQ3BAGFE'
        secret_key = 'cZFFPzHqNypczCWpHvpAaWwy2YsQmIVgn0NXJOse'
    elif s == 's3-firestorage-data':
        bucket = 'firestorage-data'
        endpoint_url = "https://s3-ap-northeast-1.amazonaws.com"
        region = 'ap-northeast-1'
        access_key = 'AKIA2DZTPU34L62LYBFK'
        secret_key = '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'
    elif s == 'b2-firestorage-data':
        bucket = 'firestorage-data'
        endpoint_url = "https://s3.us-west-004.backblazeb2.com"
        region = 'us-west-004'
        access_key = '0048f4abf77ad840000000001'
        secret_key = 'K004r51QeBgSySWT77HUSIam8RMxs3Q'
    elif s == 'index':
        bucket = 'firestorage-index'
        endpoint_url = "https://s3-ap-northeast-1.amazonaws.com"
        region = 'ap-northeast-1'
        access_key = 'AKIA2DZTPU34OCLFCLNB'
        secret_key = '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'
    elif s.find('sub') >= 0 and s.find('-firestorage-data') > 0:

        if s in _upload_cache_data:
            json_data = _upload_cache_data[s]
            bucket       = json_data['bucket']
            endpoint_url = json_data['aws_host']
            region       = json_data['region']
            access_key   = json_data['aws_access_key_id']
            secret_key   = json_data['aws_secret_access_key']
            return 201, endpoint_url, region, bucket, access_key, secret_key

        code ,body = fire_basic.s3_simple_get("firestorage-index", 'setting/server/sub.json')

        if code == 200:

            if s in _upload_cache_data:
                code = 201

            json_data = json.loads(body)
            print(json_data)
            for mykey in json_data.keys():
                    if json_data[mykey]['config'] == s:
                        _upload_cache_data[s] = json_data[mykey]['setting']
                        bucket       = json_data[mykey]['setting']['bucket']
                        endpoint_url = json_data[mykey]['setting']['aws_host']
                        region       = json_data[mykey]['setting']['region']
                        access_key   = json_data[mykey]['setting']['aws_access_key_id']
                        secret_key   = json_data[mykey]['setting']['aws_secret_access_key']
                        return code, endpoint_url, region, bucket, access_key, secret_key
        return 404, endpoint_url, region, bucket, access_key, secret_key

    if bucket == "":
        code = 404

    return code, endpoint_url, region, bucket, access_key, secret_key


def convert_size(size_bytes):
    if size_bytes == 0:
        return "0B"
    size_name = ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
    i = int(math.floor(math.log(size_bytes, 1024)))
    p = math.pow(1024, i)
    s = round(size_bytes / p, 2)
    return "%s %s" % (s, size_name[i])

def html_escape(s):
    s = s.replace("&", "&amp;") # Must be done first!
    s = s.replace("<", "&lt;")
    s = s.replace(">", "&gt;")
    s = s.replace('"', "&quot;")
    return s

def set_s3_index(bucket, key, contents):

    s3 = boto3.resource('s3')
    obj = s3.Object(bucket, key)
    obj.put(Body=contents)

    return 200, key

def remove_s3_index(bucket, key):

    s3 = boto3.resource('s3')
    obj = s3.Object(bucket, key)
    obj.delete()

    return 200, key

def get_asp(json_data):

    asp = ""

    if 'asp' in json_data['member']:
        asp = json_data['member']['asp']

    if asp == '-':
        asp = ''

    return asp

def get_payed(json_data):

    payed = 0

    if 'payed' in json_data['member']:
        if json_data['member']['payed'] == '-' or json_data['member']['payed'] == '' or json_data['member']['payed'] == 'd' :
            payed = 0
        else:
            payed = int(json_data['member']['payed'])

    print("payed:" + str(payed));

    return payed

def get_system_message(rc, lang):
    # メッセージjsonを読む

    s3_message = {}

    code, json_text = get_setting_data(rc, 'json', 'download_message')
    if code == 200:
        msg = json.loads(json_text)
        s3_message = msg[lang]

    return s3_message

def error_page(rc, domain, title_key, message_key, codes, s3_message):

    body = {}

    title   = s3_message[title_key]
    message = s3_message[message_key]

    code, html = get_setting_data(rc, 'template', 'aws_firestorage_simple_body.html')

    text = '<div class="card mx-auto mt-2 mb-2 col-xs-12 col-sm-12 col-md-8 col-lg-6 col-xl-6 col-xxl-6"><ul class="list-group list-group-flush"><li class="list-group-item pt-1 pb-1" style="background-color:#eeeeee">'
    text += title
    text += str(codes)
    text += '</li>'
    text += '<li class="list-group-item">'
    text += message
    text += '</li></ul></div>'

    html = html.replace("<CONTENT>", text)
    html = html.replace("<AD1>", "")
    html = html.replace("<AD3>", "")
    html = html.replace("<ADOV>", "")

    html = fire_basic.uri_encode(html)

    body['code'] = 200
    body['html'] = html

    return {
        'statusCode': 200,
        'headers' : {
          "Access-Control-Allow-Origin": domain
        },
        'body': json.dumps(body)
    }

def get_access_limit(json_data):

    # キーのアクセス許可時間が切れていない?
    if 'access_limit' in json_data['member']:

        # limit_time = int(download_limit_time) + int(time.time());

        limit_t = json_data['member']['access_limit']

        if limit_t < int(time.time()):
            return 403

    return 200

