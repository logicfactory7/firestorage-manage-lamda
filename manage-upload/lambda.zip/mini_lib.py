import json
import fire_basic as fb
import re

from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.utils import formatdate


def get_auth_config(rc ,group : str, auth : str):

    config = {}

    redis_key = group + ":" + auth
    text = rc.get(redis_key)

    if text is None:
        message = "redis no data"
        return 404, config, "redis no data"

    if fb.is_json(text):
        config = json.loads(text)
        return 200, config, "OK"
    else:
        return 400, config, "redis load json error"

def reset_s3_redis(rc, bucket, group, auth, key, json_data, user_key):

    data = {}

    text = fb.make_json_data(json_data)
    code = fb.s3_simple_put(bucket, key, text)
    data ['s3'] = code

    if rc.exists(group + ":" + auth):
        ttl   = rc.ttl(group + ":" + auth)
        if ttl is not None:
            code1 = rc.set(group + ":" + auth , text, ex=ttl)
            data ['code1'] = code1
            data ['ttl1']  = ttl
            data ['key1']  = auth
    if rc.exists(group + ":" + user_key):
        ttl  = rc.ttl(group + ":" + user_key)
        if ttl is not None:
            code2 = rc.set(group + ":" + user_key , text, ex=ttl)
            data ['code2'] = code2
            data ['ttl2']  = ttl
            data ['key2']  = user_key

    return data

def send_text_mail(sqs_url, mail_data):

    mail_data['subject'] = fb.uri_encode(mail_data['subject'])
    mail_data['message'] = fb.uri_encode(mail_data['message'])

    code = fb.put_sqs_data(sqs_url, mail_data)

    return code

def html_mail(rc, stage, sqs_url, mail_data):

    if 'to' not in mail_data:
        return 403, "data to or from not found"
    if 'reply' not in mail_data:
        mail_data['reply'] = ""
    if 'from' not in mail_data:
        mail_data['from'] =  "info@firestorage.jp"
    if 'returns' not in mail_data:
        mail_data['returns'] = "info@firestorage.jp"

    # --- html mail ---
    # メール送信、テンプレートを取得
    json_data = fb.get_setting_data_stage(rc, stage, "mail", 'html_mail_container')

    if 'body' not in json_data:
        #ないぞ
        return 404, stage + ":html_mail_container json_data body not found"
    html = json_data['body']
    html = fb.html_entities_decode(html)

    line = ""
    list = mail_data['message'].split("\n")
    for str in list:
        str = fb.html_escape(str)

        if str.find('firestorage') >= 0 or str.find('xfs.jp') >= 0:
            pass
        else:
            str = str.replace('.', '<span>.</span>')
            str = str.replace('@', '<span>@</span>')

        line += '<p style="font-family: Helvetica, sans-serif; font-size: 16px; font-weight: normal; margin: 0; margin-bottom: 16px;">' + str + '</p>' + "\n"

    html = html.replace("<mail_body>", line)

    # HTML5 名前付き文字参照を戻す
    msg = MIMEMultipart("alternative")
    msg["Subject"] = mail_data['subject']
    msg["From"]    = mail_data['from']
    msg["To"]      = mail_data['to']

    msg.attach(MIMEText(mail_data['message'], "plain"))
    msg.attach(MIMEText(html, "html"))

    mail_data['raw']     = msg.as_string()

    # メールを送る
    code = fb.put_sqs_data(sqs_url, mail_data)

    return code

