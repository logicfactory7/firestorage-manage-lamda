
# 修正箇所

バリテーションにeid追加

# pip3 install python-memcached -t .

check_eid を作成


get_upload_servers　パラメータにaspを追加




