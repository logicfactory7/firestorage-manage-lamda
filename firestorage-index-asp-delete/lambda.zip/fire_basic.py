
import json
import urllib.parse
import os
import math
import redis
import time
import re
import datetime
import boto3
import botocore
import random
import string
import html
import sys, base64, datetime, hashlib, hmac

from redis.cluster import RedisCluster, ClusterNode
from botocore.auth import SigV4Auth
from botocore.client import Config
from botocore.credentials import Credentials
from botocore.awsrequest import AWSRequest

import xml.etree.ElementTree as ET

from typing import List

def get_api_stage_alias(event):

    # 'stageVariables': {'alias': 'dev'}
    if 'stageVariables' in event:
        str =  event['stageVariables']['alias']
        if str == 'dev':
            return 'test'
        elif str == 'prod':
            return 'production'
        else:
            return event['stageVariables']['alias']
    else:
        return "test"

def validation_deco(queryStringParameters, input_parm):

#   sample
#    input_parm = [
#        {'key': 'user_id', 'max': 10, 'min': 0, 'type': "0-9"},
#        {'key': 'mail_address', 'max': 50, 'min': 3, 'type' : "mail", "req" : True},
#        {'key': 'domain', 'max': 50, 'min': 3, 'type' : "a-z0-9.", "req" : True},
#        {'key': 'key', 'max': 32, 'min': 4, 'type': "a-zA-Z0-9" , "req" : True},
#        {'key': 'group', 'max': 32, 'min': 4, 'type': "a-zA-Z0-9" , "req" : True},
#        {'key': 'data', 'max': 4096, 'min': 0, 'type': "*" , "decode" : True},
#    ]

    output_data = {}
    error_datas = {}
    error_count = 0
    code = 200

    if queryStringParameters is None:
        item = {}
        item['code'] = 404
        item['message'] = 'no datas'
        error_datas["Null"] = item
        return 404, output_data, error_datas
    else:

      for hash in input_parm:
        key = hash['key']
        type = hash['type']

        reqs = False
        if 'req' in hash.keys():
            reqs = hash['req']

        deco = False
        if 'decode' in hash.keys():
            deco = hash['decode']

        lists = False
        if 'list' in hash.keys():
            lists = True

        num = False
        if 'num' in hash.keys():
            num = True

        item = {}
        codes = 200
        value = ""

        if key in queryStringParameters.keys():
            value = queryStringParameters[key]

        if value == "":
            # 必須か？
            if reqs == True:
                error_count = error_count + 1
                codes = 400
                item['code'] = 400
                item['message'] = key + ' validation req error(no data)'
                error_datas[key] = item
            else:
                output_data[key] = ""
        else:
            if deco == True:
                #デコードする？
                value = urllib.parse.unquote(value)

            if type == "0-9" or type == 'a-z0-9-' or type == 'a-f0-9' or type == 'a-z0-9_.,' or type == 'a-z0-9_.' or type == "a-zA-Z0-9." or type == "a-z0-9." or type == 'a-zA-Z0-9' or type == 'a-z0-9' or \
               type == 'a-z0-9_' or type == 'a-z0-9_,' or type == 'a-zA-Z0-9_':

                if lists == True:
                    i = 0
                    for value2 in value.split('\t'):
                        i += 1
                        code2 = validation_length(hash, value2, None)
                        val = re.sub("[^'" + type + "']", "", value2)

                        if val != value2 or code2 != 200:
                            msg = 'check'
                            if code2 != 200:
                                msg = 'check length'
                            error_count = error_count + 1
                            codes = 400
                            item['code'] = 400
                            item['message'] = key + ' validation ' + msg + ' error ' + type + ":" + val
                            error_datas[key] = item

                else:
                    val = re.sub("[^'" + type + "']", "", value)
                    if val != value:
                        error_count = error_count + 1
                        codes = 400
                        item['code'] = 400
                        item['message'] = key + ' validation check error ' + type + ":" + val
                        error_datas[key] = item

            elif type == 'mail':
                pattern = "^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$"
                if re.match(pattern, value):
                    pass
                else:
                    error_count = error_count + 1
                    codes = 400
                    item['code'] = 400
                    item['message'] = key + ' validation check error ' + type + ":" + val
                    error_datas[key] = item
            elif type == "*":
                pass
            elif type == "":
                pass
            else:
                error_count = error_count + 1
                codes = 400
                item['code'] = 400
                item['message'] = 'validation type not found error ' + type
                error_datas[key] = item

            if codes== 200:
                    if num == True:
                        value = int(value)
                    output_data[key] = value

    error_data = {}
    error_data['count'] = error_count

    if error_count > 0:
        code = 400
        error_data['error'] = error_datas
        error_data['count'] = error_count

    return code, output_data, error_data

def validation_length(hash, value, lists):

    if lists is not None:
        return 200

    if len(value) > hash['max'] or len(value) < hash['min']:
        return 400
    else:
        return 200

def domain_check(domain):

    if '.firestorage.jp' in domain:
        return False
    elif 'firestorage.jp' in domain:
        return False
    elif 'xfs.jp' in domain:
        return False
    else:
        return True

def get_ip_address(event):

    if event.get('requestContext') is None:
        return ""
    else:
       env = event.get('requestContext')
       return env['identity']['sourceIp']

def get_user_agent(event):

    if event.get('requestContext') is None:
        return ""
    else:
       env = event.get('requestContext')
       ua = env['identity']['userAgent']
       if ua.find('iPhone', 0) > 0 or ua.find('iPod', 0) > 0 or ua.find('Android', 0) > 0 and ua.find('Mobile', 0) > 0:
          return 'mobile'
       elif ua.find('iPad', 0) > 0 or ua.find('Android', 0 ) > 0:
          return 'tablet'
       else:
          return 'PC'

def get_logic_ip_check(event):

    ip = get_ip_address(event)

    if ip == '125.206.201.254' or ip ==  '39.110.234.252' or ip ==  '118.238.27.179':
        return True

    return False

def redis_connect():

    redis_host = os.environ['redis_host']
    redis_port = os.environ['redis_port']

    nodes = [
       {"host": redis_host, "port": redis_port}
    ]

    cluster_nodes = [ClusterNode(**node) for node in nodes]
    rc = RedisCluster(startup_nodes=cluster_nodes, read_from_replicas=True)

    return rc

def get_sqs_data(queue_url: str):

    if queue_url is None:
        return 404, ""

    sqs_client = boto3.client("sqs")

    response = sqs_client.receive_message(QueueUrl=queue_url, MaxNumberOfMessages=1, VisibilityTimeout=60)

    if 'Messages' in response and response['Messages']:

        message = response['Messages'][0]
        receipt_handle = message['ReceiptHandle']

        # 消す
        sqs_client.delete_message(
            QueueUrl=queue_url,
            ReceiptHandle=receipt_handle
        )

        return 200, response

    return 404, ""

def put_sqs_data(queue_url: str, data: dict):

    # dataは辞書型
    try:
        sqs_client = boto3.client("sqs")
        enque_result = sqs_client.send_message(QueueUrl=queue_url, MessageBody=json.dumps(data))
        if 'Failed' in enque_result:
           print(enque_result)
           return 500
        return 200
    except:
        return 502

def get_stage():

    # これ廃止寸前使わない様に

    stage = os.environ['stage']

    if stage is None:
        stage = 'test'

    return stage


def get_setting_stage_data(rc, stage, type, key):

    data = rc.hget("setting/" + stage + ":" + type , key)

    if is_json(data):
        return json.loads(data)
    else:
        return {}

def get_setting_data_stage(rc, stage, type, key):

    data = rc.hget("setting/" + stage + ":" + type , key)

    if is_json(data):
        return json.loads(data)
    else:
        return {}

def get_setting_data(rc, type, key):

    # これ廃止寸前使わない様に

    data = get_setting_data_stage(rc, get_stage(), type, key)

    return data

def uri_encode(data):
    data = urllib.parse.quote(data)
    return data

def uri_decode(data):
    data = urllib.parse.unquote(data)
    return data

def get_unixtime():

    # エポック時間を取得
    t2 = int(time.time())

    return t2

def s3_compatible_put(s3_data, key, contents):

    s3 = boto3.resource('s3',
        endpoint_url = s3_data['aws_host'],
        aws_access_key_id = s3_data['access_key'],
        aws_secret_access_key = s3_data['secret_key']
    )

    try:
        obj = s3.Object(s3_data['bucket'], key)
        obj.put(Body=contents)
        return 200
    except botocore.exceptions.ClientError as e:
        return 500

def s3_simple_copy(bucket, key, to_key):

    s3 = boto3.resource('s3')

    try:
        obj = s3.Object(bucket, to_key)
        obj.copy_from(CopySource={'Bucket': bucket, 'Key': key})
        return 200
    except botocore.exceptions.ClientError as e:
        return 500

def s3_simple_put(bucket, key, contents):

    s3 = boto3.resource('s3')

    try:
        obj = s3.Object(bucket, key)
        obj.put(Body=contents)
        return 200
    except botocore.exceptions.ClientError as e:
        return 500

def s3_simple_set_tag(bucket, key, tag_key, tag_value):

    s3 = boto3.client('s3')
    try:
        res = s3.put_object_tagging(
            Bucket=bucket,
            Key=key,
            Tagging={
                'TagSet': [
                    {
                        'Key': tag_key,
                        'Value': tag_value,
                    },
                ],
            },
        )

        return 200
    except botocore.exceptions.ClientError as e:
        return 500

def s3_simple_delete_single(bucket, key):

    s3 = boto3.client('s3')

    try:
        response = s3.delete_object(Bucket=bucket, Key=key)
        return 200
    except botocore.exceptions.ClientError as e:
        if e.response['Error']['Code'] == "404":
            # The key does not exist.
            return 404
        elif e.response['Error']['Code'] == '403':
            # Unauthorized, including invalid bucket
            return 403
        else:
            return 500

def s3_simple_head(bucket, key):

    s3 = boto3.client('s3')

    try:
        response = s3.head_object(Bucket=bucket, Key=key)
        return 200
    except botocore.exceptions.ClientError as e:
        if e.response['Error']['Code'] == "404":
            # The key does not exist.
            return 404
        elif e.response['Error']['Code'] == '403':
            # Unauthorized, including invalid bucket
            return 403
        else:
            return 500

def s3_simple_get(bucket, key):

    s3 = boto3.client('s3')

    try:
        response = s3.get_object(Bucket=bucket, Key=key)
        text = response['Body'].read()
        text = text.decode('utf8')
        return 200, text
    except s3.exceptions.NoSuchKey as e:
        if e.response["Error"]["Code"] == "NoSuchKey":
            return 404, ""
        else:
            return 500, ""

def s3_delete_keys(bucket, keys):

    s3 = boto3.client('s3')
    response = s3.delete_objects(Bucket=bucket,
        Delete={
            'Objects': keys,
            'Quiet': False
        }
    )
    return 200

def bucket_list(bucket: str, prefix: str, Delimiter: str, marker: str, MaxKeys :int):
    """S3上のファイルリスト取得
    Args:
        bucket (str): バケット名
        prefix (str): バケット以降のパス
        recursive (bool): 再帰的にパスを取得するかどうか
    """
    if MaxKeys is None:
        MaxKeys = 1000
    elif MaxKeys > 1000:
        MaxKeys = 1000

    s3 = boto3.client('s3')
    keys = []

    try:
        response = s3.list_objects(
            Bucket=bucket, Prefix=prefix, Marker=marker, Delimiter=Delimiter, MaxKeys=MaxKeys, EncodingType='url')
        if len(response) > 0:
            pass
        else :
            return 404, keys
    except botocore.exceptions.ClientError as e:
        if e.response['Error']['Code'] == "404":
            return 404, keys
        else:
            pass
    except KeyError as e:
        return 500, keys

    if 'CommonPrefixes' in response:
        # Delimiterが'/'のときはフォルダがKeyに含まれない
        return 200, response['CommonPrefixes']

    if 'Contents' in response:  # 該当する key がないと response に 'Contents' が含まれない
        for item in response['Contents']:
            data = {}

            print(item['LastModified'])

            data['key']  = item['Key']
            data['date'] = item['LastModified'].strftime('%Y-%m-%d %H:%M:%S')
            data['size'] = item['Size']
            data['etag'] = item['ETag']
            keys.append(data)

        return 200, keys

    return 404, keys

def __get_all_keys(bucket: str, prefix: str, MaxKeys: int, keys: List = None, marker: str = '', recursive: bool = False) -> List[str]:
    """指定した prefix のすべての key の配列を返す
    Args:
        bucket (str): バケット名
        prefix (str): バケット以降のパス
        keys (List): 全パス取得用に用いる
        marker (str): 全パス取得用に用いる
        recursive (bool): 再帰的にパスを取得するかどうか

    """
    print("prefix:" + prefix)
    print("bucket:" + bucket)

    s3 = boto3.client('s3')
    if recursive:
        response = s3.list_objects(
            Bucket=bucket, Prefix=prefix, Marker=marker, MaxKeys=MaxKeys)
        print ("recursive")
    else:
        response = s3.list_objects(
            Bucket=bucket, Prefix=prefix, Marker=marker, Delimiter='/', MaxKeys=MaxKeys, EncodingType='url')
        print ("recursive else")

    # keyがNoneのときは初期化
    if keys is None:
        keys = []

    if 'CommonPrefixes' in response:
        # Delimiterが'/'のときはフォルダがKeyに含まれない
        print(response)
        keys.extend(
            [content['Prefix'] for content in response['CommonPrefixes']]
        )

    if 'Contents' in response:  # 該当する key がないと response に 'Contents' が含まれない
        keys.extend([content['Key'] for content in response['Contents']])
        if 'IsTruncated' in response:
            return __get_all_keys(bucket=bucket, prefix=prefix, keys=keys, marker=keys[-1], recursive=recursive)

    return keys


def make_json_data(json_data):
    return json.dumps(json_data,indent=4, sort_keys=True)

def is_json(json_str):
   try:
        json.loads(json_str)
   except json.JSONDecodeError as e:
        return False
   # 以下の例外でも捕まえるので注意
   except ValueError as e:
        return False
   except Exception as e:
        return False
   return True

def source_ip_check(event):

    env = event.get('requestContext')

    if env is None:
        return 404, ""

    source_ip = os.environ['source_ip']

    ip = env['identity']['sourceIp']

    for x in source_ip.split(','):
        if ip == x:
            return 200, ip

    else:
        return 400, ip

def convert_size(size_bytes):
    if size_bytes == 0:
        return "0B"
    size_name = ("バイト", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
    i = int(math.floor(math.log(size_bytes, 1024)))
    p = math.pow(1024, i)
    s = round(size_bytes / p, 2)
    return "%s %s" % (s, size_name[i])

def html_escape(s):
    s = s.replace("&", "&amp;") # Must be done first!
    s = s.replace("<", "&lt;")
    s = s.replace(">", "&gt;")
    s = s.replace('"', "&quot;")
    return s

def file_name_escape(s):

    s = s.replace('\\', "￥")
    s = s.replace('/', "／")
    s = s.replace('*', "＊")
    s = s.replace('?', "？")
    s = s.replace('"', '”')
    s = s.replace('<', '＜')
    s = s.replace('>', '＞')
    s = s.replace('|', '｜')
    s = s.replace('`', '｀')
    s = s.replace(',', '，')
    s = s.replace(':', '：')
    s = s.replace(';', '；')
    s = s.replace('=', '＝')

    return s

def html_entities_encode(s):

    s = html.escape(s, quote=True)
    return s

def html_entities_decode(s):

    #HTML5 名前付き文字参照を戻す
    s = html.unescape(s)
    return s

def get_firestorage_index_config():

    s3_data = {}
    s3_data['bucket'] = 'firestorage-index'
    s3_data['endpoint_url'] = "https://s3-ap-northeast-1.amazonaws.com"
    s3_data['region'] = 'ap-northeast-1'
    s3_data['access_key'] = 'AKIA2DZTPU34OCLFCLNB'
    s3_data['secret_key'] = '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'

    return s3_data

def get_xfs_key(event, url):

    code , response = get_sqs_data(os.environ['xfs_sqs'])

    Messages = response['Messages'][0]
    print("get_sqs_data")
    print(code)
    print(Messages)

    bucket_name = "firestorage-index-xfs"

    if 'Body' in Messages:

        text      = Messages['Body']
        json_data = json.loads(text)

        key = json_data['key']

        unix_time = get_unixtime()

		# my $sql = "update mini_url_tbl set user_id = '$user_id' , file_id = '$id2' , sslup = '$sslup' , payed = '$payed' , ip_address = '$REMOTE_ADDR' , date_d = '$dated' , add_time = '$myTime' , del_time = '0' , del_exp = '0' , del = '2'  where id = '$id' ";

        data = {}
        data['add_date'] = unix_time
        data['comment'] = ""
        data['date_d'] =  datetime_str(unix_time, 'yyyy-mm-dd hh:mm:ss')

        data['del'] = "2"
        data['del_exp'] = "0"
        data['del_time'] = 0
        data['file_id']  = 0
        data['id'] = 0
        data['images'] = 0
        data['ip_address'] = get_ip_address(event)
        data['jump'] = url
        data['last_time'] = unix_time
        data['pass'] = ""
        data['pass_hint'] = ""

        data['payed'] = "-"
        data['sha1_key'] = ""
        data['sslup'] = "1"
        data['timestamp'] = ""
        data['title'] = ""
        data['url'] = key
        data['user_id'] = 0

        json_text = json.dumps(data)

        s_1, s_2, s_3 = key[:2], key[2:4], key[4:6]
        get_key = 'xfs/' + s_1 + '/' + s_2 + '/' + s_3 + '/' + key + '.json'

        code = s3_simple_put(bucket_name, get_key, json_text)

        return code, key

    else:
        return 404, ""

def access_text_log(event, dir, data, keys):

    # sample
    # dir  : "recaptcha",
    # keys : "time,country,ip,success,org,url,ua",
    sqs_url = "https://sqs.ap-northeast-1.amazonaws.com/695355811576/firestirage-sqs-text-log"

    unix_time = get_unixtime()
    date = datetime_str(unix_time, 'yyyy-mm-dd hh:mm:ss')

    if 'date' in keys:
        data['date'] = date
    if 'ip' in keys:
        data['ip'] = get_ip_address(event)

    hash =  {}
    hash['dir'] = dir
    hash['keys'] = keys
    hash['data'] = data
    hash['time'] = unix_time

    code = put_sqs_data(sqs_url, hash)

    return code

def get_rand_str(type, key_length):

    if type =='0-9':
        return 200, ''.join(random.choices(string.digits, k=key_length))
    elif type =='0-9a-z':
        return 200, ''.join(random.choices(string.ascii_lowercase + string.digits, k=key_length))
    elif type =='0-9a-zA-Z':
        return 200, ''.join(random.choices(string.ascii_lowercase + string.ascii_uppercase + string.digits, k=key_length))
    else:
        return 403, ""

def get_rand_str_expir(rc, type, key_length, expir_sec):

    # ランダムな文字を有効期限内でダブり発行させない
    code = 400

    for num in range(10):
        code, str = get_rand_str(type, key_length)
        if code != 200:
            return code, ""
        rep = rc.set("get_rand_str:" + str, 1, ex=expir_sec, nx=True)
        if rep == True:
            return code, str

    return code, ""

def datetime_str(unix_time: int, type: str):

    # unixtimeを読める形に
    dt = datetime.datetime.fromtimestamp(unix_time)

    # JSTとUTCの差分日本時間にセット
    DIFF_JST_FROM_UTC = 9

    dt = dt + datetime.timedelta(hours=9)

    if type == 'yyyy-mm-dd hh:mm:ss':
        return dt.strftime('%Y-%m-%d %H:%M:%S')
    elif type == 'yyyy-mm-dd':
        return dt.strftime('%Y-%m-%d')
    elif type == 'yyyymmdd':
        return dt.strftime('%Y%m%d')

    return dt.strftime('%Y-%m-%d %H:%M:%S')

def csize(size, unit="B"):

    units = ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB")
    i = units.index(unit.upper())
    size = round(size / 1024 ** i, 2)

    return f"{size} {units[i]}"

def s3_xml_tag(xml):

    xml = xml.replace("&", "&amp¥")
    xml = xml.replace("\"", "&quot;")
    xml = xml.replace("<",  "&lt;" )
    xml = xml.replace(">",  "&gt;")
    xml = xml.replace("'",  "&apos;")

    return xml

def create_aws_v4(url_, method, region, access_key, secret_key, endpoint_url):

    ### 2. Credential生成
    credentials = Credentials(access_key, secret_key)
    ### 3. AWSRequest生成
    request = AWSRequest(method=method, url=url_ )
    ### 4. AWSリクエスト署名
    SigV4Auth(credentials, 's3', region).add_auth(request)
    Host = endpoint_url.replace("https://", "")
    ### 5. API発行
    headers = {
        'Authorization': request.headers['Authorization'],
        'Host':Host,
        'X-Amz-Date':request.context['timestamp']
    }

    return headers

def create_v4_sha256(method, config, parm, header, body):

    # x-amz-content-sha256 が生成される

    region  = config['region']
    host    = config['aws_fdqn']
    bucket  = config['bucket']
    service = "s3"
    access_key    = config['aws_access_key_id']
    secret_key    = config['aws_secret_access_key']

    # Create a date for headers and the credential string
    t = datetime.datetime.utcnow()
    amzdate = t.strftime('%Y%m%dT%H%M%SZ')
    datestamp = t.strftime('%Y%m%d') # Date w/o time, used in credential scope
    # ************* TASK 1: CREATE A CANONICAL REQUEST *************
    canonical_uri = "/%s" % bucket
    request_parameters =  parm
    payload_hash = hashlib.sha256(body.encode("utf-8")).hexdigest()

    add_head = {}
    for key in header.keys():
        add_head[key] = header[key]
    add_head['host'] = host
    add_head['x-amz-content-sha256'] = payload_hash
    add_head['x-amz-date'] = amzdate
    sort_head = sorted(add_head.items())
    sort_head = dict((x, y) for x, y in sort_head)

    # 並べ替える
    canonical_headers = ""
    signed_headers    = ""
    for key in sort_head.keys():
        if canonical_headers == "":
           signed_headers     = key
           canonical_headers += key + ':' + sort_head[key] + '\n'
        else:
           signed_headers    += ";" + key
           canonical_headers += key + ':' + sort_head[key] + '\n'

    canonical_request = method + '\n' + canonical_uri + '\n' + request_parameters + '\n' + canonical_headers + '\n' + signed_headers + '\n' + payload_hash
    # ************* TASK 2: CREATE THE STRING TO SIGN*************
    algorithm = 'AWS4-HMAC-SHA256'
    credential_scope = datestamp + '/' + region + '/' + service + '/' + 'aws4_request'
    string_to_sign = algorithm + '\n' +  amzdate + '\n' +  credential_scope + '\n' +  hashlib.sha256(canonical_request.encode('utf-8')).hexdigest()
    # ************* TASK 3: CALCULATE THE SIGNATURE *************
    signing_key = getSignatureKey(secret_key, datestamp, region, service)
    signature = hmac.new(signing_key, (string_to_sign).encode('utf-8'), hashlib.sha256).hexdigest()
    # ************* TASK 4: ADD SIGNING INFORMATION TO THE REQUEST *************
    authorization_header = algorithm + ' ' + 'Credential=' + access_key + '/' + credential_scope + ', ' +  'SignedHeaders=' + signed_headers + ', ' + 'Signature=' + signature

    headers = {'x-amz-date':amzdate, 'x-amz-content-sha256': payload_hash, 'Authorization':authorization_header}

    # 増えたヘッダーをプラス
    for key in header.keys():
        headers[key] = header[key]

    return headers

def sign(key, msg):
    return hmac.new(key, msg.encode('utf-8'), hashlib.sha256).digest()

def getSignatureKey(key, dateStamp, regionName, serviceName):
    kDate = sign(('AWS4' + key).encode('utf-8'), dateStamp)
    kRegion = sign(kDate, regionName)
    kService = sign(kRegion, serviceName)
    kSigning = sign(kService, 'aws4_request')
    return kSigning

def asp_domain_check(domain, member_data):

    name = domain.split('.')

    if name[0] == 'www':
       return 200, ""
    if name[0] == 'firestorage':
       return 200, ""
    elif name[0] == 'xfs.jp':
       return 200, ""

    if 'asp' in member_data:
        if  len(member_data['asp']) > 1:
            if name[0] == member_data['asp']:
                return 201, name[0]

    return 200, ""


