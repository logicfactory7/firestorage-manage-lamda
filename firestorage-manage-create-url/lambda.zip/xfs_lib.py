
import os
import string
import json
import random
import fire_basic

def create_xfs_url(rc , url: str, password : str, exp : int, user_id : int, ip_address : str):

    bucket = 'firestorage-index-xfs'
    times = fire_basic.get_unixtime()

    data = {}
    data['add_time'] = times
    data['comment'] = ""
    data['date_d'] = fire_basic.datetime_str(times, "yyyymmdd")
    data['del'] = "2"
    data['del_exp'] = str(exp)
    data['del_time'] = exp
    data['file_id'] = 0
    data['id'] = 0
    data['images'] = 0
    data['ip_address'] = ip_address
    data['jump'] = ""
    data['last_time'] = times
    data['pass'] = password
    data['pass_hint'] = ""
    data['payed'] = "-"
    data['sha1_key'] = ""
    data['sslup'] = "1"
    data['timestamp'] = ""
    data['title'] = ""
    data['url'] = ""
    data['user_id'] = user_id

    for num in range(10):

        key = ''.join(random.choices(string.ascii_lowercase + string.digits, k=8))

        s_1, s_2, s_3 = key[:2], key[2:4], key[4:6]
        get_key =  s_1 + '/' + s_2 + '/' + s_3 + '/' + key + '.json'

        mem_key = "create_xfs_url:" + key

        rep = rc.set(mem_key, 1, ex=86400, nx=True)

        code = 500
        if rep:
            code = fire_basic.s3_simple_head(bucket, 'xfs/' + get_key)

        if code == 404:
            data['url'] = key
            data['jump'] = url
            json_text = json.dumps(data, indent=2)
            print(json_text)
            print('xfs/' + get_key)
            code = fire_basic.s3_simple_put(bucket, 'xfs/' + get_key, json_text)
            print('xfs/' + get_key + "/" + str(code))
            if code != 200:
                return 403, url
            return 200, "https://xfs.jp/" + key

    return 403, url

