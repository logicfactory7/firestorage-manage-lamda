import os
import requests
import urllib.parse
import xmltodict
import datetime
import boto3
import botocore
import dateutil
import hashlib
import base64

from requests.exceptions import Timeout
from botocore.client import Config
from botocore.endpoint import URLLib3Session
from botocore.credentials import Credentials
from botocore.awsrequest import AWSRequest
from botocore.auth import SigV4Auth

import xml.etree.ElementTree as ET
from requests.exceptions import Timeout

def create_proxy_url(method, s3_data, key):

    proxy_url    = os.environ['proxy_url']
    endpoint_url = s3_data['aws_host']
    Host         = endpoint_url.replace("https://", "")

    ### 1.APIエンドポイントURL
    url_ = s3_data['aws_host'] + "/" + s3_data['bucket'] + "/" + key
    ### 2. Credential生成
    credentials = Credentials(s3_data['aws_access_key_id'], s3_data['aws_secret_access_key'])
    ### 3. AWSRequest生成
    request = AWSRequest(method=method, url=url_)
    ### 4. AWSリクエスト署名
    SigV4Auth(credentials, 's3', s3_data['region']).add_auth(request)
    ### 5. API発行
    headers = {
        'Authorization': request.headers['Authorization'],
        'Host':Host,
        'X-Amz-Date':request.context['timestamp']
    }

    return proxy_url + "/" + Host + "/" + s3_data['bucket']  + "/" + key, headers

def s3_simple_put(s3_data, key, contents):

    if isinstance(s3_data, dict):

        url, headers = create_proxy_url('PUT', s3_data, key)

        try:
            r = requests.put(url, timeout=(3.0, 5.0), headers=headers, data=contents)
            code = r.status_code
            return code
        except Timeout:
            return 501

    else:
        s3 = boto3.resource('s3')

        try:
            obj = s3.Object(s3_data, key)
            obj.put(Body=contents)
            return 200
        except botocore.exceptions.ClientError as e:
            return 500

def s3_simple_get(s3_data, key):

    if isinstance(s3_data, dict):

        url, headers = create_proxy_url('GET', s3_data, key)

        try:
            body = ""
            r = requests.get(url, timeout=(3.0, 5.0), headers=headers, data="")
            code = r.status_code

            if code == 200:
                body = r.text
            return code, body
        except Timeout:
            return 501

    else:

        s3 = boto3.resource('s3')

        try:
            response = s3.get_object(Bucket=s3_data, Key=key)
            text = response['Body'].read()
            text = text.decode('utf8')
            return 200, text
        except botocore.exceptions.ClientError as e:
            if e.response["Error"]["Code"] == "NoSuchKey":
                return 404, ""
            else:
                return 500, ""

def s3_simple_delete_single(s3_data, key):

    if isinstance(s3_data, dict):

        url, headers = create_proxy_url('DELETE', s3_data, key)

        try:
            body = ""
            r = requests.delete(url, timeout=(3.0, 5.0), headers=headers, data="")
            code = r.status_code
            return code
        except Timeout:
            return 501

    else:

        s3 = boto3.resource('s3')

        try:
            response = s3.delete_object(Bucket=s3_data, Key=key)
            return 200
        except botocore.exceptions.ClientError as e:
            if e.response["Error"]["Code"] == "NoSuchKey":
                return 404
            else:
                return 500

def s3_simple_delete_multi(s3_data, keys):

    if isinstance(s3_data, dict):

        delete = ""

        for item in keys:
            delete += "  <Object>\n"
            delete += "  <Key>" +  item + "</Key>\n"
            delete += "  </Object>\n"

        if len(delete) > 0:
            xml  = '<?xml version="1.0" encoding="UTF-8"?>' + "\n"
            xml += "<Delete>\n"
            xml += delete + "</Delete>\n"

        # MD5変換
        hash_md5 = hashlib.md5(xml.encode()).digest()
        hash_md5 = base64.b64encode(hash_md5).decode()

        print("s3_simple_delete_multi")
        print(f'MD5: {hash_md5}')

        proxy_url    = os.environ['proxy_url']
        endpoint_url = s3_data['aws_host']
        Host         = endpoint_url.replace("https://", "")

        ### 1.APIエンドポイントURL
        url_ = s3_data['aws_host'] + "/" + s3_data['bucket'] + "?delete"
        ### 2. Credential生成
        credentials = Credentials(s3_data['aws_access_key_id'], s3_data['aws_secret_access_key'])
        ### 3. AWSRequest生成
        request = AWSRequest(method="POST", url=url_)
        ### 4. AWSリクエスト署名
        SigV4Auth(credentials, 's3', s3_data['region']).add_auth(request)
        ### 5. API発行
        headers = {
            'Authorization': request.headers['Authorization'],
            'Host': Host,
            'Content-Md5': hash_md5,
            'content-type': "text/xml",
            'X-Amz-Date':request.context['timestamp']
        }

        url = proxy_url + "/" + Host + "/" + s3_data['bucket']  + "?delete"

        try:
            r = requests.post(url, timeout=(3.0, 5.0), headers=headers, data=xml)
            code = r.status_code
            body = r.text
            return code, body
        except Timeout:
            return 501, ""

    else:

        s3 = boto3.resource('s3')

        try:

            response = s3.delete_objects(
                Bucket = s3_data,
                Delete = {
                    'Objects': keys
                }
            )
            return 200
        except botocore.exceptions.ClientError as e:
            if e.response["Error"]["Code"] == "NoSuchKey":
                return 404
            else:
                return 500

def s3_simple_head(s3_data, key):

    if isinstance(s3_data, dict):

        url, headers = create_proxy_url('HEAD', s3_data, key)

        try:
            r = requests.head(url, timeout=(3.0, 5.0), headers=headers, data="")
            code = r.status_code
            return code
        except Timeout:
            return 501

    else:

        s3 = boto3.resource('s3')

        try:
            response = s3.head_object(Bucket=s3_data, Key=key)
            return 200
        except botocore.exceptions.ClientError as e:
            if e.response['Error']['Code'] == "404":
                # The key does not exist.
                return 404
            elif e.response['Error']['Code'] == '403':
                # Unauthorized, including invalid bucket
                return 403
            else:
                return 500

def s3_simple_sign(s3_data, method , key, exp_time):

    endpoint_url = s3_data['aws_host']
    bucket_name  = s3_data['bucket']
    region       = s3_data['region']
    access_key   = s3_data['aws_access_key_id']
    secret_key   = s3_data['aws_secret_access_key']

    # put_object / get_object など

    s3_client = boto3.client('s3', config=Config(signature_version='s3v4'), endpoint_url=endpoint_url, region_name=region, aws_access_key_id=access_key, aws_secret_access_key=secret_key)
    url = s3_client.generate_presigned_url(method, Params={'Bucket': bucket_name, 'Key': key }, ExpiresIn=exp_time)

    return url

def bucket_list(s3_data, prefix: str, Delimiter: str, marker: str, MaxKeys :int):
    """S3上のファイルリスト取得
    Args:
        bucket (str): バケット名
        prefix (str): バケット以降のパス
        recursive (bool): 再帰的にパスを取得するかどうか
    """
    if MaxKeys is None:
        MaxKeys = 1000
    elif MaxKeys > 1000:
        MaxKeys = 1000

    bucket = ""

    if isinstance(s3_data, dict):

        region       = s3_data['region']
        endpoint_url = s3_data['aws_fdqn']
        bucket       = s3_data['bucket']
        access_key   = s3_data['aws_access_key_id']
        secret_key   = s3_data['aws_secret_access_key']

        list = []
        if len(Delimiter) > 0:
            list.append("delimiter=" + Delimiter)

        if MaxKeys > 0:
            list.append("max-keys=" + str(MaxKeys))

        list.append('prefix=' + urllib.parse.quote(prefix, safe=''))

        parm = "&".join(list)

        url, headers = create_proxy_url('GET', s3_data, "?" + parm)

        try:
            r = requests.get(url, headers=headers, timeout=(3.0, 5.0) )
            code = r.status_code

            if code == 200:

                xml_data = r.text
                json = xmltodict.parse(xml_data)
                print("xmltodict")
                print(json)

                response = json['ListBucketResult']
                data = {}

                if 'CommonPrefixes' in response:
                    # Delimiterが'/'のときはフォルダがKeyに含まれない
                    data['response'] = 'CommonPrefixes'
                    list = []
                    if type(response['CommonPrefixes']) is list:
                        list.append(response['CommonPrefixes'])
                        data['list']  = list
                        data['count'] = len(list)
                        return 200, data
                    else:
                        data['list'] =  response['CommonPrefixes']
                        data['count'] = len(response['CommonPrefixes'])
                        return 200, data

                elif 'Contents' in response:  # 該当する key がないと response に 'Contents' が含まれない

                    data['response'] = 'Contents'
                    keys = []

                    JST = datetime.timezone(datetime.timedelta(hours=+9), 'JST')
                    root = ET.fromstring(xml_data)
                    # 子ノードを読み込む
                    for child1 in root:
                        value = {}
                        for child2 in child1:
                            if child2.tag.find('Key') > 0:
                                value['key'] = child2.text
                            elif child2.tag.find('Size') > 0:
                                value['size'] = child2.text
                            elif child2.tag.find('LastModified') > 0:
                                date = child2.text
                                # dateutil.parser.parse(str_datetime).astimezone(JST)
                                date = dateutil.parser.parse(date).astimezone(JST)
                                value['date'] = date.strftime("%Y-%m-%d %H:%M:%S")
                            elif child2.tag.find('ETag') > 0:
                                value['etag'] = child2.text
                        if 'key' in value:
                            keys.append(value)

                    data['list'] = keys
                    data['count'] = len(keys)
                    return 200, data
                else:
                    data = {}
                    data['count'] = 0
                    return code, data

        except requests.exceptions.RequestException as e:
            data = {}
            data['count'] = 0
            print("エラー : ",e)
            return 500, data

        data = {}
        data['count'] = 0
        return code, data

    else:

        s3 = boto3.client('s3')
        keys = []

        try:
            response = s3.list_objects(
                Bucket=s3_data, Prefix=prefix, Marker=marker, Delimiter=Delimiter, MaxKeys=MaxKeys, EncodingType='url')
            if len(response) > 0:
                pass
            else :
                return 404, keys
        except botocore.exceptions.ClientError as e:
            if e.response['Error']['Code'] == "404":
                return 404, keys
            else:
                pass
        except KeyError as e:
            return 500, keys



    if 'CommonPrefixes' in response:
        # Delimiterが'/'のときはフォルダがKeyに含まれない
        return 200, response['CommonPrefixes']

    if 'Contents' in response:  # 該当する key がないと response に 'Contents' が含まれない
        for item in response['Contents']:
            data = {}

            print(item['LastModified'])

            data['key']  = item['Key']
            data['date'] = item['LastModified'].strftime('%Y-%m-%d %H:%M:%S')
            data['size'] = item['Size']
            data['etag'] = item['ETag']
            keys.append(data)

        return 200, keys

    return 404, keys
